import java.util.Scanner;
public class main {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);


        Circulo c1 = new Circulo(3);
        System.out.println("Calculos do circulo:");
        System.out.println(c1.calcularArea());
        System.out.println(c1.calcularPerimetro());
        System.out.println("===============================");

        Quadrado q1 = new Quadrado(1);
        System.out.println("Calculos do quadrado:");
        System.out.println(q1.calcularAreaQ());
        System.out.println(q1.calcularPerimetroQ());
        System.out.println("===============================");

//        Retangulo r1 = new Retangulo(2);
//        System.out.println("Calculos do retangulo");
//        System.out.println(r1.);



    }
}
