import java.util.Scanner;
public class Quadrado {
    double lado;

    Quadrado(double lado){
        this.lado=lado;

    }


    double calcularAreaQ()
    {return lado * lado;}


    double calcularPerimetroQ()

    {return lado * 4;}

}
