import java.util.Scanner;
public class Retangulo {
    double lado1, lado2;

        Retangulo(double lado1){
            this.lado1=lado1;}

        double calcularAreaP()
        {return lado1 * lado2;}

        double calcularPerimetroP()

        {return lado1 * 2 + lado2 * 2;}


    }

