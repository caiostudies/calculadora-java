package bosch;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);


        Circulo c1 = new Circulo(3);
        System.out.println(c1.calcularArea());
        System.out.println(c1.calcularPerimetro());

        Quadrado q1 = new Quadrado(1);
        System.out.println(q1.calcularPerimetroQ());



    }



}
