package bosch;

public class Main {

    public static void main(String[] args) {
        Produto p1 = new Produto();
        System.out.println(p1.somar(2,3));
        System.out.println(p1.somar(1,2));










       /* Produto p1 = new Produto();
        p1.nome = ("Notebook");
        p1.preco = 4449.89;
        p1.desconto = 0.10;

        Produto p2 = new Produto();
        p2.nome = "Shampoo";
        p2.preco = 16.50;
        p2.desconto = 0.25;

        System.out.println(p1.nome);
        System.out.println(p2.nome);*/


    }
}
