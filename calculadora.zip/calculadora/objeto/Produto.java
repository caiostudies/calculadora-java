package bosch;

public class Produto {

    int somar(int par1, int par2){

        return par1 + par2;
    }

    void printarHelloNaTela(){
        System.out.println("Hello");
    }

    int somar(double par1, double par2){
        return (int) (par1+par2);
    }




    /*String nome;
    double preco;
    double desconto;*/



}
